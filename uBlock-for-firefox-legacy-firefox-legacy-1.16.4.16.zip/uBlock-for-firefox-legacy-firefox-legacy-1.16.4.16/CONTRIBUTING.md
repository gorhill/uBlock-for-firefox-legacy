# Submitting issues

Submit on <https://github.com/uBlockOrigin/uBlock-issues/issues>.

Issue tracker here is read-only for non-[prior contributors](https://github.com/gorhill/uBlock/graphs/contributors).
