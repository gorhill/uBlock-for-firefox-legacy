#!/usr/bin/env bash
#
# This script assumes a linux environment

echo "*** uBlock: Cleaning."
rm -R dist/build
echo "*** uBlock: Cleaned."
